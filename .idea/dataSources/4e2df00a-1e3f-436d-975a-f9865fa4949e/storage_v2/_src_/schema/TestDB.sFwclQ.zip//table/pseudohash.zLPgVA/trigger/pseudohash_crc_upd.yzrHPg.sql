create definer = root@`%` trigger pseudohash_crc_upd
  before UPDATE
  on pseudohash
  for each row
BEGIN SET
NEW.url_crc = crc32(NEW.url);
END;

